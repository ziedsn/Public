Proof-of-Concept Trojan (it is NOT volatile so it will not permanently do anything to your machines) that requires some testing before being sent to a client. Please can some of you run this on your machines (ones that are in use) so that we can test it is working as expected.

It will do the following;
-	send all your keystrokes to a webserver
-	send captures of your screen to a webserver every 15mins

It has been designed to have a low memory footprint so should not cause you any troubles, it also encrypts all data it sends with blowfish to prevent it being sniffed on the wire.


This code actually sucks, is very buggy, and index.php.txt contains a directory traversal vulnerability, numerous DoS conditions occur. Lame.