// SofUpdate.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols
#include "SofUpdate_i.h"


// CSofUpdateApp:
// See SofUpdate.cpp for the implementation of this class
//

class CSofUpdateApp : public CWinApp
{
public:
	CSofUpdateApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
public:
	BOOL ExitInstance(void);
};

extern CSofUpdateApp theApp;