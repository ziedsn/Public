// Decryptor.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Decryptor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;
	cout << "SofUpdate file decryptor tool" << endl;
	if(argc < 2){
		cout << "You need to supply a filename" << endl;
		exit(0);
	}
	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		CFileException ex;
		CFile sourceFile;
		sourceFile.Open(CString(argv[1]), CFile::modeRead | CFile::shareDenyNone, &ex); 
		ULONGLONG size = sourceFile.GetLength();		
		BYTE* buffer = new byte[size];
		BYTE* blowbuffer = new byte[size];
		memset(blowbuffer,0,size);
		DWORD dwRead;			
		dwRead = sourceFile.Read(buffer, size);		
		sourceFile.Close();	
		// blowfish buffer size of buffer, buffer is original, blowbuffer for output		
		CBlowFish oBlowFish((unsigned char*)"prdelkar0xw0rLdz", 16);		
		oBlowFish.Decrypt((unsigned char*)buffer,(unsigned char*)blowbuffer, size, CBlowFish::CBC);		
		DeleteFile(CString(argv[1]));		
		CFile destFile;
		destFile.Open(CString(argv[1]), CFile::modeWrite|CFile::shareExclusive|CFile::modeCreate, &ex);		
		destFile.Write(blowbuffer, size);
		destFile.Close();
	}

	return nRetCode;
}
